# Héctor OS

Asistente personal privado, móvil y modular sobre Cloudflare Workers. Incluye frontend React, API Hono, D1, R2 y OpenAI Responses API.

## Arquitectura

```mermaid
flowchart TD
  I[iPhone / navegador] --> W[Cloudflare Worker]
  W --> A[Autenticación y API]
  A --> D[(D1: usuarios, memoria, chat, finanzas, calendario)]
  A --> R[(R2: archivos)]
  A --> O[OpenAI Responses API]
```

La clave de OpenAI existe únicamente como secreto del Worker. El navegador usa una cookie `HttpOnly`, `Secure` y `SameSite=Strict`. El registro inicial queda cerrado después de crear al primer propietario.

## Estado del producto

- Autenticación de propietario único y sesiones de 30 días.
- Dashboard móvil con balance, calendario, archivos y memoria.
- Chat persistente con continuidad mediante `previous_response_id`.
- Memoria personal explícita, visible y eliminable.
- Archivos privados hasta 10 MB almacenados en R2.
- Esquemas iniciales para finanzas, calendario y auditoría.
- Interfaz adaptable a iPhone y escritorio.

## Desarrollo local

Requisitos: Node.js 22+, cuenta Cloudflare y Wrangler autenticado.

```bash
npm install
npm run db:migrate:local
npm run dev
```

Para probar el chat localmente, crea `.dev.vars` (está ignorado por Git):

```dotenv
OPENAI_API_KEY=tu_clave_de_desarrollo
```

No uses una clave pegada en un chat ni la publiques en variables `VITE_*`.

## Despliegue en Cloudflare

1. Inicia sesión y crea los recursos:

```bash
npx wrangler login
npx wrangler d1 create hector-os-db
npx wrangler r2 bucket create hector-os-files
```

2. Copia el `database_id` devuelto por D1 en `wrangler.jsonc`.

3. Aplica el esquema remoto:

```bash
npm run db:migrate:remote
```

4. Configura el secreto mediante el prompt seguro de Wrangler:

```bash
npx wrangler secret put OPENAI_API_KEY
```

5. Despliega:

```bash
npm run deploy
```

6. Abre la URL `workers.dev`, toca **Configurar por primera vez** y registra al propietario. Después de ese registro, `/api/auth/register` rechazará usuarios nuevos.

## Módulos y extensión

Las rutas están separadas en `worker/routes`; la lógica transversal vive en `worker/lib`; D1 conserva el estado estructurado y R2 los bytes. Para una integración futura:

1. añade tablas mediante una migración nueva;
2. crea un módulo en `worker/routes`;
3. aplica `requireAuth` a todas sus rutas;
4. registra acciones sensibles en `audit_log`;
5. expón herramientas de IA solo con validación Zod y confirmación explícita para escrituras o envíos.

## Seguridad antes de producción pública

- Revoca cualquier clave de API que alguna vez haya sido pegada en texto o capturas.
- Activa límites de gasto y alertas en OpenAI Platform.
- Configura un dominio propio y Cloudflare Access si quieres una segunda capa.
- Añade rate limiting al login y a `/api/chat` antes de compartir la URL.
- Haz respaldos periódicos de D1 y habilita políticas de retención para archivos.

## Comandos

| Comando | Uso |
|---|---|
| `npm run dev` | Worker y frontend local |
| `npm run build` | Typecheck y build de producción |
| `npm run db:migrate:local` | Aplica migraciones locales |
| `npm run db:migrate:remote` | Aplica migraciones a D1 remoto |
| `npm run deploy` | Compila y despliega |

